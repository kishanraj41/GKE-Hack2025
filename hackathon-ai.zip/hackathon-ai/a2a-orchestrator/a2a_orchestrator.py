import os
import json
import asyncio
from datetime import datetime
from typing import Dict, List

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import google.generativeai as genai

# Initialize FastAPI
app = FastAPI(title="A2A Orchestrator - Hackathon")

# Add CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Gemini
genai.configure(api_key=os.environ.get("GEMINI_API_KEY", ""))
model = genai.GenerativeModel('gemini-1.5-flash')

# WebSocket connections
active_connections: Dict[str, WebSocket] = {}

# Simple agent simulation
class SimpleAgent:
    def __init__(self, name: str, role: str):
        self.name = name
        self.role = role
        self.message_count = 0
    
    async def process(self, task: str) -> Dict:
        """Simulate agent processing"""
        self.message_count += 1
        
        # Simulate different agent behaviors
        if self.role == "pricing":
            return {
                "agent": self.name,
                "action": "price_optimization",
                "result": f"Optimized pricing for {task}",
                "discount": 15,
                "confidence": 0.87
            }
        elif self.role == "inventory":
            return {
                "agent": self.name,
                "action": "inventory_check",
                "result": f"Inventory checked for {task}",
                "stock_level": 42,
                "reorder_needed": False
            }
        elif self.role == "customer":
            return {
                "agent": self.name,
                "action": "customer_analysis",
                "result": f"Customer analyzed for {task}",
                "segment": "premium",
                "lifetime_value": 2500
            }
        else:
            return {
                "agent": self.name,
                "action": "generic_process",
                "result": f"Processed {task}"
            }

# Initialize agents
agents = {
    "pricing_agent": SimpleAgent("pricing_agent", "pricing"),
    "inventory_agent": SimpleAgent("inventory_agent", "inventory"),
    "customer_agent": SimpleAgent("customer_agent", "customer")
}

# Workflow tracking
workflow_history = []

@app.get("/")
async def root():
    return {"message": "A2A Orchestrator Running", "agents": list(agents.keys())}

@app.get("/status")
async def get_status():
    """Get system status"""
    return {
        "active_agents": list(agents.keys()),
        "message_count": sum(agent.message_count for agent in agents.values()),
        "workflows_executed": len(workflow_history),
        "connections_active": len(active_connections),
        "system_health": "operational"
    }

@app.post("/workflow/{workflow_name}")
async def execute_workflow(workflow_name: str, data: dict = {}):
    """Execute a predefined workflow"""
    
    workflow_id = f"{workflow_name}_{datetime.now().timestamp()}"
    results = []
    
    if workflow_name == "customer_optimization":
        # Execute customer optimization workflow
        for agent_name in ["customer_agent", "pricing_agent", "inventory_agent"]:
            agent = agents[agent_name]
            result = await agent.process(f"user_{data.get('user_id', 'unknown')}")
            results.append(result)
            
            # Broadcast to WebSocket clients
            await broadcast_update({
                "type": "workflow_progress",
                "workflow_id": workflow_id,
                "agent": agent_name,
                "status": "completed",
                "result": result
            })
    
    elif workflow_name == "price_adjustment":
        # Execute price adjustment workflow
        agent = agents["pricing_agent"]
        result = await agent.process("dynamic_pricing")
        results.append(result)
    
    else:
        return {"error": f"Unknown workflow: {workflow_name}"}
    
    # Store in history
    workflow_history.append({
        "id": workflow_id,
        "name": workflow_name,
        "timestamp": datetime.now().isoformat(),
        "results": results
    })
    
    # Use Gemini to summarize results
    try:
        prompt = f"Summarize these workflow results in one sentence: {json.dumps(results)}"
        response = model.generate_content(prompt)
        summary = response.text[:200]
    except:
        summary = f"Workflow {workflow_name} completed successfully with {len(results)} agent actions"
    
    return {
        "workflow_id": workflow_id,
        "status": "completed",
        "agents_involved": len(results),
        "summary": summary,
        "results": results
    }

@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: str):
    """WebSocket for real-time updates"""
    await websocket.accept()
    active_connections[user_id] = websocket
    
    try:
        # Send initial connection message
        await websocket.send_json({
            "type": "connection",
            "message": "Connected to A2A Orchestrator",
            "user_id": user_id
        })
        
        # Keep connection alive
        while True:
            data = await websocket.receive_text()
            
            # Echo back or process commands
            if data == "ping":
                await websocket.send_text("pong")
            else:
                # Process as command
                await websocket.send_json({
                    "type": "response",
                    "message": f"Received: {data}"
                })
    
    except WebSocketDisconnect:
        del active_connections[user_id]

async def broadcast_update(message: dict):
    """Broadcast update to all connected clients"""
    for connection in active_connections.values():
        try:
            await connection.send_json(message)
        except:
            pass

@app.get("/agents")
async def list_agents():
    """List all agents and their stats"""
    return {
        "agents": [
            {
                "name": agent.name,
                "role": agent.role,
                "messages_processed": agent.message_count
            }
            for agent in agents.values()
        ],
        "total_agents": len(agents)
    }

@app.post("/simulate-event")
async def simulate_event(event_type: str):
    """Simulate various events for demo"""
    
    events = {
        "price_drop": {
            "type": "price_drop",
            "product_name": "Vintage Camera",
            "old_price": 149.99,
            "new_price": 119.99
        },
        "low_stock": {
            "type": "low_stock",
            "product_name": "Hipster Beanie",
            "quantity": 3
        },
        "fraud_alert": {
            "type": "fraud_alert",
            "transaction_id": "txn_12345",
            "risk_score": 0.87
        }
    }
    
    if event_type in events:
        event = events[event_type]
        await broadcast_update(event)
        return {"status": "event_simulated", "event": event}
    
    return {"error": "Unknown event type"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8081)
