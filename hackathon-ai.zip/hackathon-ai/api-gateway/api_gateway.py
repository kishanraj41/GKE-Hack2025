import os
import re
import httpx
from fastapi import FastAPI, Request, Response
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="AI Gateway")

# Add CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# JavaScript widget to inject
AI_WIDGET_SCRIPT = """
<script>
console.log('AI Widget Loading...');
(function() {
    const script = document.createElement('script');
    script.src = '/ai/widget.js';
    script.async = true;
    document.head.appendChild(script);
})();
</script>
</body>"""

@app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def proxy(request: Request, path: str):
    """Proxy requests to frontend and inject AI widget"""
    
    # Skip our own endpoints
    if path.startswith("ai/"):
        return {"error": "Not found"}
    
    # Forward to original frontend
    async with httpx.AsyncClient() as client:
        url = f"http://frontend.default.svc.cluster.local/{path}"
        
        try:
            response = await client.request(
                method=request.method,
                url=url,
                headers=dict(request.headers),
                content=await request.body() if request.method in ["POST", "PUT"] else None,
                timeout=30.0
            )
            
            # Inject widget into HTML responses
            if "text/html" in response.headers.get("content-type", ""):
                content = response.text
                # Inject before closing body
                content = content.replace("</body>", AI_WIDGET_SCRIPT)
                return HTMLResponse(content=content)
            
            # Return other content as-is
            return Response(
                content=response.content,
                headers=dict(response.headers),
                status_code=response.status_code
            )
        except:
            # Fallback response
            return HTMLResponse("<h1>Online Boutique</h1><p>Gateway temporarily unavailable</p>")

@app.get("/ai/widget.js")
async def serve_widget():
    """Serve the AI widget JavaScript"""
    # Return the widget code
    with open("widget.js", "r") as f:
        return Response(content=f.read(), media_type="application/javascript")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8090)
