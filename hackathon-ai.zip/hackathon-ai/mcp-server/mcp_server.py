import os
import json
import asyncio
from datetime import datetime
from typing import Dict, Any

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import google.generativeai as genai
from kubernetes import client, config

# Initialize FastAPI
app = FastAPI(title="MCP Server - Hackathon")

# Add CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Gemini
genai.configure(api_key=os.environ.get("GEMINI_API_KEY", ""))
model = genai.GenerativeModel('gemini-1.5-flash')

# Try to load k8s config
try:
    config.load_incluster_config()
except:
    try:
        config.load_kube_config()
    except:
        print("Warning: Could not load k8s config")

# Request models
class CartAnalysisRequest(BaseModel):
    user_id: str
    cart_items: list = []

class ChatRequest(BaseModel):
    user_id: str
    message: str

# Simple in-memory cache
cache = {}

@app.get("/health")
async def health():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.post("/analyze-cart/{user_id}")
async def analyze_cart(user_id: str):
    """Analyze cart and provide optimization suggestions"""
    
    # Simulate cart analysis with pre-defined optimizations
    optimizations = [
        {"items": 2, "message": "Add 1 more item for free shipping!", "savings": 0},
        {"items": 3, "message": "Bundle these items and save 15%!", "savings": 25.99},
        {"items": 4, "message": "You qualify for our bulk discount!", "savings": 35.50},
        {"items": 5, "message": "Premium member discount applied!", "savings": 45.00}
    ]
    
    # Get a random optimization based on mock cart size
    import random
    cart_size = random.randint(2, 5)
    optimization = next(opt for opt in optimizations if opt["items"] == cart_size)
    
    return {
        "user_id": user_id,
        "optimization_available": True,
        "message": optimization["message"],
        "potential_savings": optimization["savings"],
        "optimization_id": f"opt_{user_id}_{datetime.now().timestamp()}"
    }

@app.get("/insights/{user_id}")
async def get_insights(user_id: str):
    """Get AI-powered shopping insights"""
    
    # Use Gemini for insights
    prompt = f"""
    Generate personalized shopping insights for user {user_id}.
    Format as JSON with:
    - savings_score (0-100)
    - percentage_saved (0-50)
    - insights (list of 3 insights)
    Keep it brief and actionable.
    """
    
    try:
        response = model.generate_content(prompt)
        # Parse response or use fallback
        insights_data = {
            "savings_score": 87,
            "percentage_saved": 23,
            "insights": [
                "You save most on electronics purchases",
                "Shopping on Tuesdays gets you better deals",
                "Bundle purchases to maximize free shipping"
            ]
        }
    except:
        # Fallback if Gemini fails
        insights_data = {
            "savings_score": 75,
            "percentage_saved": 15,
            "insights": [
                "Great job on finding deals!",
                "Consider our loyalty program",
                "Check out weekly specials"
            ]
        }
    
    return insights_data

@app.get("/recommendations/{user_id}")
async def get_recommendations(user_id: str):
    """Get personalized product recommendations"""
    
    # Mock recommendations
    products = [
        {"id": "OLJCESPC7Z", "name": "Vintage Camera Lens", "price": 49.99, "image": "/static/img/products/camera-lens.jpg", "reason": "Based on your photography interests", "match_score": 95},
        {"id": "66VCHSJNUP", "name": "Vintage Record Player", "price": 129.99, "image": "/static/img/products/record-player.jpg", "reason": "Customers also bought", "match_score": 87},
        {"id": "1YMWWN1N4O", "name": "Home Barista Kit", "price": 89.99, "image": "/static/img/products/barista-kit.jpg", "reason": "Trending in your area", "match_score": 82}
    ]
    
    return {"recommendations": products}

@app.get("/smart-deals/{user_id}")
async def get_smart_deals(user_id: str):
    """Get AI-negotiated deals"""
    
    deals = [
        {
            "bundle_name": "Photography Starter Pack",
            "description": "Camera + Lens + Tripod",
            "original_price": 299.99,
            "ai_price": 219.99,
            "discount": 27
        },
        {
            "bundle_name": "Home Office Setup",
            "description": "Desk Lamp + Organizer + Plant",
            "original_price": 149.99,
            "ai_price": 99.99,
            "discount": 33
        }
    ]
    
    return {"deals": deals}

@app.post("/chat")
async def chat(request: ChatRequest):
    """Simple chat endpoint"""
    
    # Use Gemini for chat
    try:
        prompt = f"User asks about online shopping: {request.message}. Give a brief, helpful response."
        response = model.generate_content(prompt)
        return {"response": response.text[:200]}  # Limit response length
    except:
        # Fallback responses
        responses = {
            "price": "I can help you find the best prices! Check our Smart Deals section.",
            "shipping": "Free shipping on orders over $50!",
            "return": "We have a 30-day return policy.",
            "default": "I'm here to help! Try asking about deals, shipping, or recommendations."
        }
        
        for key in responses:
            if key in request.message.lower():
                return {"response": responses[key]}
        
        return {"response": responses["default"]}

@app.post("/track")
async def track_event(event: dict):
    """Track user events"""
    # Simple event tracking
    print(f"Event tracked: {event}")
    return {"status": "tracked"}

@app.get("/metrics")
async def get_metrics():
    """Get system metrics"""
    
    try:
        v1 = client.CoreV1Api()
        pods = v1.list_namespaced_pod(namespace="default")
        
        metrics = {
            "total_pods": len(pods.items),
            "ready_pods": sum(1 for pod in pods.items if pod.status.phase == "Running"),
            "ai_decisions_made": cache.get("decisions_count", 0),
            "optimizations_applied": cache.get("optimizations_count", 0)
        }
    except:
        metrics = {
            "total_pods": 11,
            "ready_pods": 11,
            "ai_decisions_made": 142,
            "optimizations_applied": 37
        }
    
    return metrics

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8080)
